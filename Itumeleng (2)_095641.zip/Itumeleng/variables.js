//Exercise 1:Variable Declaration
let name = "Itumeleng Mmotlana";
let age = 23;
let isStudent = true;

//Printing the variables
console.log("Name:", name);
console.log("Age:", age);   
console.log("Is Student:", isStudent);

//Exercise 2: Variables
let favoriteColor = "Grey";

//Printing the variable of fav color
console.log("Favorite Color:", favoriteColor);

// Reassigning the value of favoriteColor
favoriteColor = "White";
console.log("Updated Favorite Color:", favoriteColor);

//Exercise 3: Arithmetic Operations
let num1 = 76;
let num2 = 53;
let sum = num1 + num2;
let difference = num1 - num2;
let product = num1 * num2;
let quotient = num1 / num2;

//Printing the results of arithmetic operations
console.log("Sum:", sum);
console.log("Difference:", difference); 
console.log("Product:", product);
console.log("Quotient:", quotient);
