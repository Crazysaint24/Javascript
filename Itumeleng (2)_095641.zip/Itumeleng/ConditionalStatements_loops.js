//Exercise 1:Temperature Check
let Temperature = 10;
 //using an if statement to check tempersture

 if (Temperature < 0){
    console.log("It's freezing!");
 }else if (Temperature >= 0 && Temperature <= 15){
    console.log("It's cold");
 }else if (Temperature >= 16 && Temperature <= 25){
    console.log("It's mild");
 }else{
    console.log("It's warm");
 }



 //Using Switch Statements
//Declaring a variable temperature
let temperature = 20;

//Switch Statement
switch (true){
    case temperature < 0:
    console.log("It's freezing!");
    break;
    case temperature >=0 && temperature <=15:
    console.log("It's cold");
    break;
    case temperature >= 16 && temperature <=25:
    console.log("It's mild");
    break;
    default:
        console.log("It's warm");
        break
}
//Exercise 2: Divisibility Check

let number = 24;

//if else statement
if (number % 2 === 0 && number % 3 === 0){
    console.log("Divisisble by both");
}else if (number % 2 === 0){
    console.log("Divisible by 2");
}else if (number % 3 === 0){
    console.log("Divisible by 3");
}else{
    console.log("Not Divisible by 2 or 3");
}

//Switch Statement
switch (true){
    case number % 2 === 0 && number % 3 === 0:
    console.log("Divisible by both");
    break;
    case number % 2 === 0:
    console.log("Divisible by 2");
    break;
    case number % 3 === 0:
    console.log("Divisible by 3");
    break;
    default:
        console.log("Not Divisible by both");
        break;}

        //Exercise 3: For loops

        //Printing numbers from 1 to 10
        for (let i = 1; i <= 10; i++){
            console.log(i);
        }

        //Printing even numbers between 1 to 20
        for (let i = 1; i <= 20; i++){
            if (i % 2 === 0){
                console.log(i);  
            }
        }

        //Calculating the sum of all numbers from 1 to 100
        let sum = 0
        for (let i = 1; i <= 100; i++){
            sum += i;
        }
        console.log(sum); 

        //Printing each element of an array
        const numbers = [1, 2, 3, 4, 5];
        for (let i = 0; i < numbers.length; i++){
            console.log(numbers[i]);
        }

        //Finding and Printing the largest number in an array
        const Numbers = [3, 7, 2, 5, 10, 6];
        let largest = Numbers[0];
        for (let i = 1; i < Numbers.length; i++){
            if (Numbers[i] > largest){
                largest = Numbers[i];
            }
           }
           console.log(largest);

           //Exercise 4: While loops

           //Printing numbers from 1 to 10
           let i = 1;
           while (i <= 10){
            console.log(i);
            i++;
           }
           
        //Printing even numbers between 1 to 20
        let j = 1;
        while (j <= 20){
            if (j % 2 === 0){
                console.log(j);   
            }
            j++;
        }
        //Calculating the sum of all numbers from 1 to 100
        let add = 0;
        let i = 1;
        while (i <= 100){
            add += i;
            i++;
        }
        console.log(add);  

        //Printing all multiples of 5 less than 50
        let i = 5;
        while (i < 50){
            console.log(i);
            i += 5;
        }
//Exercise 5: Do while loops
        //Printing numbers from 1 to 10
        let i = 1;
        do {
            console.log(i);
            i++;
            
        }while (i <= 10);

         //Calculating the sum of all numbers from 1 to 100
         let sum = 0
         let i = 1;
         do{
            sum += i;
            i++;
         }while (i <= 100);
         console.log(sum);

         //Prompt the user to enter a number greaterthan 10
         let number;
         do {
            number = parseInt(prompt("Enter a number greater than 10:"));
         } while (isNaN(number)) || number <= 10);
         console.log("Valid number entered:" numbers);

         //Simple guessing game
         let secretnumber = Math.floor(Math.random() * 10) + 1;
         let guess;







