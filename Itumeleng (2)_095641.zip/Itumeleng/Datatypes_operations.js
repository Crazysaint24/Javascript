//Exercise 1: Numbers
//Declaring a number variable and assigning a integer to it
let integer = 77;

//Declaring a variable variable and assigning a floating number to it
let floatNum = 12.50;

//Performing arithmetic operations
let addition = integer + floatNum;
let subtraction = integer - 89;
let multiplication = floatNum * 2;
let division = integer / 6;
let modulus = floatNum % 3;
let exponentiation = integer ** 3;

//Printing the results of arithmetic operations
console.log("Addition:", addition);
console.log("Subtraction:", subtraction);
console.log("Multiplication:", multiplication);
console.log("Division:", division);
console.log("Modulus:", modulus);
console.log("Exponentiation:", exponentiation);

//Exercise 2: Booleans and Operators
//Declaring variables
let X = 8;
let Y = 12;

//Comparison operators to compare x and y
let isgreater = X > Y;
let islessorequalsto =  X <= Y;
let isequal = X == Y;
let isnotEqual = X != Y;

//printing the results of comparison operations
console.log("Is X greater than Y?", isgreater);
console.log("Is X less than or equal to Y?", islessorequalsto);
console.log("Is X equal to Y?", isequal);
console.log("Is X not equal to Y?", isnotEqual);

//Logical operators
let a = true;
let b = false;

//Printing the results of logical operations
let andOperation = a && b;
let orOperation = a || b;
let notOperation = !a;

console.log("AND Operation:", andOperation);
console.log("OR Operation:", orOperation);
console.log("NOT Operation:", notOperation);

//Assignment operators
let p = 10;
//Using assignment operators to modify the value of p
p += 5; // p = p + 5
Console.log("After addition:", p); // 15
p -= 3; // p = p - 3
console.log("After subtraction:", p); // 12
p *= 2; // p = p * 2
console.log("After multiplication:", p); // 24
p /= 4; // p = p / 4
console.log("After division:", p); // 6
p %= 3; // p = p % 3
console.log("After modulus:", p); // 0
